Repo for exploring GFN streaming via a mobile WebView.

![img.png](img.png)

## Current State
Currently tested on iOS (Simulator and Native), Android (Simulator, Native) and Mac for development

Requires a monkey patch to GFN to stop it classifying the device as `unknown` which causes the
session to abort. This patch is injected when the WebView starts. The patch ensures the
request always returns a valid operating system.

On iOS emulator it works fine, on iOS native it still tries to pop a fullscreen
video view which doesn't allow input.

## Running
Ensure you have the `Expo Go` app installed on your mobile device. The project is currently configured for 
version 51.
Ensure the codebase points to a valid Showcase world that has streaming enabled.

`npm i`

`expo run start`

`i` to run the emulator, or scan the QR code on your mobile device to load natively

## DC Tests
**For Android Emulator:** download some emulator (recommended to download Android Studio, you should be able to use their default virtual device which emulates a Google Pixel Phone)
Download Expo Go for emulators and drag onto virtual device to install app on emulator

Once your emulator is up and running, in your project repo execute:
- `npx expo start`

You can then copy and paste the relevant exp:// url from the logs into the expo app. This should load an example landing page, from which you can enter our example MSquared world.

**For Android Devices:** follow the same steps as above, downloading the app onto your device.

Execute a different command in your terminal from your project directory:
- `npx expo start --tunnel` - this will allow your android device to connect.
This will require you to install an additional package - simply enter 'y' to accept and install.

Follow the rest of the procedures above (either with the url or scanning the QR code)


## Work needed
The UX should ideally maximise real estate for the streaming experience, but without
using the fullscreen API which causes it to be treated as a typical `<video>`.

This UX improvement would also improve mobile streaming experiences in general,
even if using Safari / Chrome instead of a WebView.

We should probably make the case to GFN to improve their browser classification so
the monkey patch is no longer needed.
